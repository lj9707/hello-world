from builtins import object


class ComputationalBackend(object):
    pass
